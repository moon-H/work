package org.zz.gmhelper.test;

public class GMBaseTest {
    public static final byte[] SRC_DATA = new byte[]{0, 0, 0, 0, 0, 0, 0};
    public static final byte[] WITH_ID = new byte[]{0, 0, 0, 0};
}
